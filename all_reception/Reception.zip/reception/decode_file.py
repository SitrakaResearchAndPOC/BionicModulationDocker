import json
import binascii
import time

def decode_json_to_pdf(encoded_path, chunk_size=128, wait_interval=5, max_wait_time=3600, repeat_index_0=8):
    chunks_data = {}
    indices_vus = set()
    taille_totale = None
    index_0_count = 0

    def est_chaine_hex(s):
        try:
            if isinstance(s, str):
                int(s, 16)
                return True
            else:
                return False
        except ValueError:
            return False

    start_time = time.time()
    index_0_trouve = False

    # Attente pour obtenir l'index 0
    while not index_0_trouve:
        with open(encoded_path, 'r') as file:
            for line in file:
                try:
                    chunk = json.loads(line.strip())
                except json.JSONDecodeError:
                    continue

                index = chunk.get('index')
                if index == 0:
                    taille_totale = chunk.get('taille')
                    if taille_totale is None:
                        return ""
                    checksum_attendu = format(binascii.crc32(taille_totale.to_bytes(4, byteorder='big')) & 0xFFFF, '04x')
                    if chunk.get('checksum') != checksum_attendu:
                        continue
                    index_0_count += 1
                    if index_0_count >= repeat_index_0:
                        index_0_trouve = True
                        break

        elapsed_time = time.time() - start_time
        if not index_0_trouve:
            if elapsed_time > max_wait_time:
                return ""
            time.sleep(wait_interval)

    print(f"\nIndex 0 trouvé avec succès après {index_0_count} occurrences.")
    
    # Traitement des morceaux de données
    while True:
        with open(encoded_path, 'r') as file:
            for line in file:
                try:
                    chunk = json.loads(line.strip())
                except json.JSONDecodeError:
                    continue

                index = chunk.get('index')
                if index is None or index == 0 or index in chunks_data:
                    continue

                data_hex = chunk.get('data')
                if data_hex is None or not est_chaine_hex(data_hex):
                    continue

                if len(data_hex) % 2 != 0:
                    data_hex = '0' + data_hex  # Assurer une longueur hex paire

                data = binascii.unhexlify(data_hex.encode('utf-8'))
                checksum_attendu = format(binascii.crc32(data) & 0xFFFF, '04x')
                if chunk.get('checksum') == checksum_attendu:
                    chunks_data[index] = data
                    indices_vus.add(index)

        if indices_vus:
            total_indices = len(indices_vus)
            expected_total_chunks = max(indices_vus)
            pourcentage_complete = (total_indices / expected_total_chunks) * 100

            elapsed_time = time.time() - start_time
            minutes = int(elapsed_time // 60)
            secondes = int(elapsed_time % 60)
            print(f"\rComplétion: {pourcentage_complete:.2f}% - Temps écoulé: {minutes}m {secondes}s", end='', flush=True)

            indices_manquants = set(range(1, expected_total_chunks + 1)) - indices_vus
            if not indices_manquants:
                break

        if time.time() - start_time > max_wait_time:
            return ""

        time.sleep(wait_interval)

    print()  # Pour aller à la ligne après la fin de la boucle

    # Assemblage des données
    decoded_data = b""
    for i in range(1, expected_total_chunks + 1):
        if i in chunks_data:
            decoded_data += chunks_data[i]
        else:
            return ""

    if len(decoded_data) != taille_totale:
        return ""

    output_pdf_path = 'decoded_file.pdf'
    with open(output_pdf_path, 'wb') as file:
        file.write(decoded_data)

    return output_pdf_path

# Utilisation de la fonction pour décoder un fichier .txt encodé au format JSON
encoded_path = 'decode_file.txt'
decoded_pdf_path = decode_json_to_pdf(encoded_path)

if decoded_pdf_path:
    print(f"\nLe fichier PDF décodé a été écrit dans : {decoded_pdf_path}")
else:
    print("\nLe décodage du fichier encodé a échoué.")

