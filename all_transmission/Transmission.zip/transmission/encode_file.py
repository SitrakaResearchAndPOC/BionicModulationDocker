import json
import binascii

def encoder_en_json(fichier_pdf, chunk_size=128, repeat_index_0=8, repeat_last_chunk=2):
    with open(fichier_pdf, 'rb') as file:
        data = file.read()
    
    total_size = len(data)
    chunks = []
    print(f"Taille totale du fichier PDF: {total_size} octets")
    
    # Encoder les morceaux de données
    for i in range(0, total_size, chunk_size):
        chunk_data = data[i:i + chunk_size]
        data_hex = binascii.hexlify(chunk_data).decode('utf-8')
        checksum = format(binascii.crc32(chunk_data) & 0xFFFF, '04x')
        chunk = {
            'index': i // chunk_size + 1,
            'data': data_hex,
            'checksum': checksum
        }
        chunks.append(json.dumps(chunk))
        # print(f"Encodage du morceau {chunk['index']}: taille={len(chunk_data)} octets, checksum={checksum}")

    # Ajouter un index 0 avec la taille totale
    size_checksum = format(binascii.crc32(total_size.to_bytes(4, byteorder='big')) & 0xFFFF, '04x')
    index_0 = {
        'index': 0,
        'taille': total_size,
        'checksum': size_checksum
    }
    
    # Répéter l'index 0
    for _ in range(repeat_index_0):
        chunks.insert(0, json.dumps(index_0))
        # print(f"Encodage de l'index 0: taille={total_size}, checksum={size_checksum}")

    # Répéter le dernier morceau de données
    if chunks:
        last_chunk = chunks[-1]  # Dernier morceau
        for _ in range(repeat_last_chunk):
            chunks.append(last_chunk)  # Ajouter une copie du dernier morceau

    return chunks

# Exemple d'utilisation
fichier_pdf = '/transmission/test.pdf'
chunks = encoder_en_json(fichier_pdf)

# Écriture dans un fichier
with open('encoded_file.txt', 'w') as f:
    for chunk in chunks:
        f.write(chunk + '\n')
print(f"Encodage terminé. Les morceaux sont écrits dans 'encoded_file.txt'.")

